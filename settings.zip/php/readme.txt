This sample is composed from 5 files:
1. api.class.php - A class which handles the application settings API calls.
2. settings.php - The setting page which resides on the developer web site for managing the publisher's application settings.
3. settings_post.php - A php file which handles the posted form from settings.php and perform the operation against the API web service.
4. settings.xml - The application settings XML template to use for adding new applications.
5. api_request_template.xml - A template file for the API request message.